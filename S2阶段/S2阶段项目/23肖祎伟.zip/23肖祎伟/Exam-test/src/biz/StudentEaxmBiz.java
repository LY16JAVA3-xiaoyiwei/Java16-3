package biz;

import java.util.List;
import java.util.Set;

import po.Answer;
import po.ST;
import po.Student;
import po.TestPaper;
import po.Writer;
import tools.PageBean;

public interface StudentEaxmBiz {
	public List<TestPaper> list(int sid);

	public TestPaper paper(int tid);

	public List<ST> Writerlist1(int tid, int did);

	public ST Writerlist(int tid, int p);

	public PageBean pagelist(int tid);

	public Student student(int sid);

	public int updaan(int wid, String s);

	public List<Answer> answers(int sid);

	public List<ST> Writerlist(int tid);

	public int uptest(int sid,int did);

}
