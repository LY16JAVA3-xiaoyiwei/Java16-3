package biz.imp;

import java.util.List;

import dao.StudentLoginDao;
import dao.WriterListDao;
import dao.imp.StudentLoginDaoImp;
import dao.imp.WriterListDaoImp;

import po.Direction;
import po.Paragraph;
import po.Subject;
import po.Writer;
import biz.WriterListBiz;

public class WriterListBizImp implements WriterListBiz {
	WriterListDao dao = new WriterListDaoImp();
	public int save(Writer writer ,int sid ) {
		// TODO Auto-generated method stub
		return dao.save(writer, sid);
	}




	public List<Direction> directions() {
		// TODO Auto-generated method stub
		return dao.directions();
	}

	public List<Paragraph> paragraphs() {
		// TODO Auto-generated method stub
		return dao.paragraphs();
	}

	public Subject subjects(int id) {
		// TODO Auto-generated method stub
		return dao.subjects(id);
	}

	public List<Object[]> object(int did, int pid) {
		// TODO Auto-generated method stub
		return dao.object(did, pid);
	}

	public int update(Writer writer,int sid) {
		
		return dao.update(writer,sid);
	}

	public Writer idlist(int wid) {
		// TODO Auto-generated method stub
		return dao.idlist(wid);
	}

	public Paragraph par(int pid) {
		// TODO Auto-generated method stub
		return dao.par(pid);
	}
	public List<Writer> wrList(int sid, int count,int p) {
		// TODO Auto-generated method stub
		return dao.wrList(sid, count,p);
	}





	




}
