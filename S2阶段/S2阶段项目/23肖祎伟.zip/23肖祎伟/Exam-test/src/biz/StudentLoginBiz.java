package biz;




import po.Acc;
import po.Student;



public interface StudentLoginBiz {
	public Student StudentLogin(String name ,String pwd);
	public Acc AccLogin(String name ,String pwd);

}
