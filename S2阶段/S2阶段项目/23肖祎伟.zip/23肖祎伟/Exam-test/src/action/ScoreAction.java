package action;

import java.util.List;

import biz.ScoreEaxmBiz;
import biz.imp.ScoreEaxmBizImp;

import po.Answer;
import po.Scores;
import po.Subject;
import po.TestPaper;

public class ScoreAction {
	private List<TestPaper> list;
	private List<Subject> subjects;
	private List<Scores> scores;
 	private int sid;
	private String subid;
	private int tid;
	private Scores sco;
	private List<Answer> answers;
	ScoreEaxmBiz biz = new ScoreEaxmBizImp();
	public String list(){
		System.out.println(sid);
		if (sid!=0) {
			subjects = biz.subjects();
			list = biz.list(sid);
			
		} else {
			subjects = biz.subjects();
			list = biz.list();
		}
		return "list";
		
	}
	public String  list1(){
		System.out.println(subid);
		int sid = Integer.valueOf(subid);
		subjects = biz.subjects();
		list = biz.sulist(sid);
		return "list";
	}
	public String score(){
		if (sid!=0) {
			scores = biz.scores(sid, tid);
			tid = scores.size();
		} else {
			System.out.println(tid);
            scores = biz.scores(tid);
            tid = scores.size();
            System.out.println(scores);
		}
		return "score";
		
	}
	public String sco(){
		sco = biz.sco(sid);
		
		System.out.println(sco.getTestPaper().getSubject().getSname());

		
		answers = biz.answers(tid);
		sid = answers.size();
		
		return "sco";
		
	}
	public List<TestPaper> getList() {
		return list;
	}
	public void setList(List<TestPaper> list) {
		this.list = list;
	}
	public List<Subject> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<Subject> subjects) {
		this.subjects = subjects;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSubid() {
		return subid;
	}
	public void setSubid(String subid) {
		this.subid = subid;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public List<Scores> getScores() {
		return scores;
	}
	public void setScores(List<Scores> scores) {
		this.scores = scores;
	}
	public Scores getSco() {
		return sco;
	}
	public void setSco(Scores sco) {
		this.sco = sco;
	}
	public List<Answer> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
	

}
