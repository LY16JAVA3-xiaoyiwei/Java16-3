package action;

import javax.swing.JOptionPane;

import org.apache.struts2.ServletActionContext;

import po.Acc;
import po.Student;
import biz.StudentLoginBiz;
import biz.imp.StudentLoginBizImp;



public class LoginAction {
	private String name;
	private String pwd;
	private int role;
	private Student student;
	private Acc acc;
	private StudentLoginBiz biz = new StudentLoginBizImp();
	public String login(){
		if (role == 1) {
			student = biz.StudentLogin(name, pwd);
			if (student != null) {
				System.out.println(role);
				System.out.println(student.getSname());
				ServletActionContext.getRequest().getSession().setAttribute("student",student);
				ServletActionContext.getRequest().getSession().setAttribute("role",role);
				JOptionPane.showMessageDialog(null, "��¼�ɹ�!");
				return "index";
			} else {
				JOptionPane.showMessageDialog(null, "��¼ʧ��!");
				return "login";
			}
		} else {
			acc = biz.AccLogin(name, pwd);
			if (acc != null) {
				System.out.println(role);
				System.out.println(acc.getNam());
				ServletActionContext.getRequest().getSession().setAttribute("acc",acc);
				ServletActionContext.getRequest().getSession().setAttribute("role",role);
				JOptionPane.showMessageDialog(null, "��¼�ɹ�!");
				return "index";
				
			} else {
				JOptionPane.showMessageDialog(null, "��¼ʧ��!");
				return "login";
			}
		}

		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Acc getAcc() {
		return acc;
	}
	public void setAcc(Acc acc) {
		this.acc = acc;
	}







}
