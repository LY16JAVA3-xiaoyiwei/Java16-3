package dao;



import org.hibernate.Session;

import po.Acc;
import po.Student;



public interface StudentLoginDao {
	public Session session = HibernateSessionFactory.getSession();
	public Student StudentLogin(String name ,String pwd);
	public Acc AccLogin(String name ,String pwd);

}
