package dao;


import java.sql.Timestamp;
import java.util.List;


import org.hibernate.Session;

import po.Classes;
import po.ST;
import po.Subject;
import po.TestPaper;
import po.Writer;



public interface TestPaperListDao {
	public Session session = HibernateSessionFactory.getSession();
    public  List<TestPaper> test();
    public int upId(int tid);
    public int delete(int tid);
    public int update(int tid,String classes,String time,String time1);
    public TestPaper testList(int sid);
    public List<Classes> clalist();
    public List<Subject> subjects();
    public int insettestpaper(int[] test1,TestPaper testPaper,int sid);
    public int insettestpaper(int a ,int b ,int c,int a1,int b1,int c1,TestPaper testPaper,int sid);
    public List<Writer> writers();
    public List<TestPaper> test(int sid,int state);
    public List<ST> sts (int sid);
	public int upda(int tid,String classes,String time,String time1);
}
