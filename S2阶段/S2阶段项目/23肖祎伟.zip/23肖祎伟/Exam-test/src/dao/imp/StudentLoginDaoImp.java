package dao.imp;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import po.Acc;
import po.Student;


import dao.StudentLoginDao;

public class StudentLoginDaoImp implements StudentLoginDao {

	public Acc AccLogin(String name, String pwd) {
		String hql = "select a from Acc a where a.nam = ? and a.pwd = ?";
		Query query =   session.createQuery(hql);
		query.setString(0, name);
		query.setString(1, pwd);
		return (Acc) query.uniqueResult();
	}

	public Student StudentLogin(String name, String pwd) {
		String hql = "select s from Student  s where s.nam = ? and s.pwd = ?";
		Query query =   session.createQuery(hql);
		query.setString(0, name);
		query.setString(1, pwd);
		return (Student) query.uniqueResult();
	}








}
