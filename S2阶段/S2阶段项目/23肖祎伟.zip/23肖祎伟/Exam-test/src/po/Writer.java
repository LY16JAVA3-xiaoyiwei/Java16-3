package po;

import java.util.HashSet;
import java.util.Set;

/**
 * Writer entity. @author MyEclipse Persistence Tools
 */

public class Writer implements java.io.Serializable {

	// Fields

	private Integer wid;
	private Subject subject;
	private String genrn;
	private String conter;
	private String types;
	private String aname;
	private String bname;
	private String cname;
	private String dname;
	private String allright;
	private String wram;
	private String chapter;
	private Set answers = new HashSet(0);
	private Set STs = new HashSet(0);

	// Constructors

	/** default constructor */
	public Writer() {
	}

	/** minimal constructor */
	public Writer(Integer wid) {
		this.wid = wid;
	}

	/** full constructor */
	public Writer(Integer wid, Subject subject, String genrn, String conter,
			String types, String aname, String bname, String cname,
			String dname, String allright, String wram, String chapter,
			Set answers, Set STs) {
		this.wid = wid;
		this.subject = subject;
		this.genrn = genrn;
		this.conter = conter;
		this.types = types;
		this.aname = aname;
		this.bname = bname;
		this.cname = cname;
		this.dname = dname;
		this.allright = allright;
		this.wram = wram;
		this.chapter = chapter;
		this.answers = answers;
		this.STs = STs;
	}

	// Property accessors

	public Integer getWid() {
		return this.wid;
	}

	public void setWid(Integer wid) {
		this.wid = wid;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getGenrn() {
		return this.genrn;
	}

	public void setGenrn(String genrn) {
		this.genrn = genrn;
	}

	public String getConter() {
		return this.conter;
	}

	public void setConter(String conter) {
		this.conter = conter;
	}

	public String getTypes() {
		return this.types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public String getAname() {
		return this.aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getBname() {
		return this.bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getAllright() {
		return this.allright;
	}

	public void setAllright(String allright) {
		this.allright = allright;
	}

	public String getWram() {
		return this.wram;
	}

	public void setWram(String wram) {
		this.wram = wram;
	}

	public String getChapter() {
		return this.chapter;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public Set getAnswers() {
		return this.answers;
	}

	public void setAnswers(Set answers) {
		this.answers = answers;
	}

	public Set getSTs() {
		return this.STs;
	}

	public void setSTs(Set STs) {
		this.STs = STs;
	}

}