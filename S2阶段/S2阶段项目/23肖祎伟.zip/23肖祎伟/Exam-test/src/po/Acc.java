package po;

/**
 * Acc entity. @author MyEclipse Persistence Tools
 */

public class Acc implements java.io.Serializable {

	// Fields

	private Integer aid;
	private String nam;
	private String pwd;
	private String role;

	// Constructors

	/** default constructor */
	public Acc() {
	}

	/** minimal constructor */
	public Acc(Integer aid) {
		this.aid = aid;
	}

	/** full constructor */
	public Acc(Integer aid, String nam, String pwd, String role) {
		this.aid = aid;
		this.nam = nam;
		this.pwd = pwd;
		this.role = role;
	}

	// Property accessors

	public Integer getAid() {
		return this.aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public String getNam() {
		return this.nam;
	}

	public void setNam(String nam) {
		this.nam = nam;
	}

	public String getPwd() {
		return this.pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}