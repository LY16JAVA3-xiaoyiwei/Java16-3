package po;

/**
 * ST entity. @author MyEclipse Persistence Tools
 */

public class ST implements java.io.Serializable {

	// Fields

	private Integer stid;
	private TestPaper testPaper;
	private Writer writer;

	// Constructors

	/** default constructor */
	public ST() {
	}

	/** minimal constructor */
	public ST(Integer stid) {
		this.stid = stid;
	}

	/** full constructor */
	public ST(Integer stid, TestPaper testPaper, Writer writer) {
		this.stid = stid;
		this.testPaper = testPaper;
		this.writer = writer;
	}

	// Property accessors

	public Integer getStid() {
		return this.stid;
	}

	public void setStid(Integer stid) {
		this.stid = stid;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Writer getWriter() {
		return this.writer;
	}

	public void setWriter(Writer writer) {
		this.writer = writer;
	}

}