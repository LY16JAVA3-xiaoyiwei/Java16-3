package po;

/**
 * Scores entity. @author MyEclipse Persistence Tools
 */

public class Scores implements java.io.Serializable {

	// Fields

	private Integer cid;
	private TestPaper testPaper;
	private Student student;
	private Integer sco;

	// Constructors

	/** default constructor */
	public Scores() {
	}

	/** minimal constructor */
	public Scores(Integer cid) {
		this.cid = cid;
	}

	/** full constructor */
	public Scores(Integer cid, TestPaper testPaper, Student student,
			 Integer sco) {
		this.cid = cid;
		this.testPaper = testPaper;
		this.student = student;
	
		this.sco = sco;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public TestPaper getTestPaper() {
		return this.testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	

	public Integer getSco() {
		return this.sco;
	}

	public void setSco(Integer sco) {
		this.sco = sco;
	}

}