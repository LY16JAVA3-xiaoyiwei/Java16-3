package po;

import java.util.HashSet;
import java.util.Set;

/**
 * Paragraph entity. @author MyEclipse Persistence Tools
 */

public class Paragraph implements java.io.Serializable {

	// Fields

	private Integer pid;
	private String pname;
	private Set subjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public Paragraph() {
	}

	/** minimal constructor */
	public Paragraph(Integer pid) {
		this.pid = pid;
	}

	/** full constructor */
	public Paragraph(Integer pid, String pname, Set subjects) {
		this.pid = pid;
		this.pname = pname;
		this.subjects = subjects;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return this.pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Set getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Set subjects) {
		this.subjects = subjects;
	}

}